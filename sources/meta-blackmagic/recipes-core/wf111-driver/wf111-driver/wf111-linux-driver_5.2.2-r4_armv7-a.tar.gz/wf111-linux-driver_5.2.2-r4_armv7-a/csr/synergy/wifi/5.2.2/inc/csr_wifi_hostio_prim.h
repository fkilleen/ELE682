/*
 *
 * Copyright (C) 2012 by Cambridge Silicon Radio Ltd.
 *
 * Refer to LICENSE.txt included with this source code for details on
 * the license terms.
 *
 */


#ifndef CSR_WIFI_HOSTIO_H
#define CSR_WIFI_HOSTIO_H

#ifdef __cplusplus
extern "C" {
#endif


#define CSR_WIFI_HOSTIO_PRIM 0x0453

#ifdef __cplusplus
}
#endif

#endif /* CSR_WIFI_HOSTIO_H */

